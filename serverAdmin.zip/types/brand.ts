export type BRAND = {
  role: string;
  name: string;
  whatsapp: string;
};
