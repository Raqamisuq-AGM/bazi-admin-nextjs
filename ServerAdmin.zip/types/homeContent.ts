export type HOMECONTENT = {
    title: string;
    content: string;
  };
  